#ifndef LABEL_HH
#define LABEL_HH

#include "component.hh"

namespace base_widgets {

    struct label_events {
        lv_event_cb_t on_click = nullptr;
        lv_event_cb_t on_long_press = nullptr;
        lv_event_cb_t on_pressed = nullptr;
        lv_event_cb_t on_released = nullptr;
        lv_event_cb_t on_focused = nullptr;
        lv_event_cb_t on_defocused = nullptr;
    };

    struct label_props {
        const char* text = nullptr;
        Styling style;
        label_events events;
    };

    class Label : public Component {
    private:
        const label_props* props;

        ~Label() override {
            delete props;
        };

    public:
        explicit Label(lv_obj_t* parent, const label_props* props)
            : Component(lv_label_create(parent)), props(props) {}

        lv_obj_t* render() override {
            lv_obj_t* obj = get_component();

            // Установка текста
            if (props->text && *props->text != '\0') {
                lv_label_set_text(obj, props->text);
            }

            // События
            const auto& e = props->events;

            if (e.on_click)       lv_obj_add_event_cb(obj, e.on_click, LV_EVENT_CLICKED, nullptr);
            if (e.on_long_press)  lv_obj_add_event_cb(obj, e.on_long_press, LV_EVENT_LONG_PRESSED, nullptr);
            if (e.on_pressed)     lv_obj_add_event_cb(obj, e.on_pressed, LV_EVENT_PRESSED, nullptr);
            if (e.on_released)    lv_obj_add_event_cb(obj, e.on_released, LV_EVENT_RELEASED, nullptr);
            if (e.on_focused)     lv_obj_add_event_cb(obj, e.on_focused, LV_EVENT_FOCUSED, nullptr);
            if (e.on_defocused)   lv_obj_add_event_cb(obj, e.on_defocused, LV_EVENT_DEFOCUSED, nullptr);

            return obj;
        }

        Styling styling() override {
            return props->style;
        }

        Label* append(lv_obj_t* obj) override {
            lv_obj_set_parent(obj, get_component());
            return this;
        }
    };

} // namespace base_widgets

#endif // LABEL_HH
