//
// Created by evgeniy on 3/29/25.
//

#ifndef VIEW_HH
#define VIEW_HH

#include "component.hh"
#include "../lvgl__lvgl/demos/lv_demos.h"
#include <memory>

extern "C" {
    #include "esp_log.h"
    #include "waveshare_rgb_lcd_port.h"
    #include "freertos/FreeRTOS.h"
    #include "driver/uart.h"
    #include "esp_log.h"
    #include "sdkconfig.h"
}

/*
 *
 *
* typedef enum {
    LV_FLEX_ALIGN_START,
    LV_FLEX_ALIGN_END,
    LV_FLEX_ALIGN_CENTER,
    LV_FLEX_ALIGN_SPACE_EVENLY,
    LV_FLEX_ALIGN_SPACE_AROUND,
    LV_FLEX_ALIGN_SPACE_BETWEEN,
} lv_flex_align_t;

typedef enum {
    LV_FLEX_FLOW_ROW                 = 0x00,
    LV_FLEX_FLOW_COLUMN              = _LV_FLEX_COLUMN,
    LV_FLEX_FLOW_ROW_WRAP            = LV_FLEX_FLOW_ROW | _LV_FLEX_WRAP,
    LV_FLEX_FLOW_ROW_REVERSE         = LV_FLEX_FLOW_ROW | _LV_FLEX_REVERSE,
    LV_FLEX_FLOW_ROW_WRAP_REVERSE    = LV_FLEX_FLOW_ROW | _LV_FLEX_WRAP | _LV_FLEX_REVERSE,
    LV_FLEX_FLOW_COLUMN_WRAP         = LV_FLEX_FLOW_COLUMN | _LV_FLEX_WRAP,
    LV_FLEX_FLOW_COLUMN_REVERSE      = LV_FLEX_FLOW_COLUMN | _LV_FLEX_REVERSE,
    LV_FLEX_FLOW_COLUMN_WRAP_REVERSE = LV_FLEX_FLOW_COLUMN | _LV_FLEX_WRAP | _LV_FLEX_REVERSE,
} lv_flex_flow_t;
 */


namespace base_widgets {

struct view_props {
    short width = LV_PCT(100);
    short height = LV_SIZE_CONTENT;
    std::shared_ptr<Styling> style;
    lv_flex_align_t justify_content = LV_FLEX_ALIGN_START;
    lv_flex_align_t align_items = LV_FLEX_ALIGN_CENTER;
    lv_flex_align_t track_cross_place = LV_FLEX_ALIGN_START;
    lv_flex_flow_t flex_direction = LV_FLEX_FLOW_COLUMN;
} typedef view_props;


    class View final : public Component {
        const view_props props;
        lv_obj_t *parent;
    public:
        explicit View(lv_obj_t *parent, const view_props& props)
            : Component(lv_obj_create(parent)), props(props), parent(parent)
        {
            set_style(props.style);
        }

        ~View() override = default;

        lv_obj_t* render() override {

            lv_obj_t* comp = get_component();
            lv_obj_set_layout(comp, LV_LAYOUT_FLEX);
            lv_obj_set_size(comp, props.width, props.height);
            lv_obj_set_flex_flow(comp, props.flex_direction);
            lv_obj_set_flex_align(comp, props.justify_content, props.align_items, props.track_cross_place);

            return comp;
        }

        Styling styling() override {
            if (this->props.style)
                return *this->props.style;
            return {};
        }

        View* append(lv_obj_t *obj) override {
            lv_obj_set_parent(obj, get_component());
            return this;
        }
    };


} // namespace base_widgets

#endif //VIEW_HH
