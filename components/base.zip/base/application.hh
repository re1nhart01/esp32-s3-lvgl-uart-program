#pragma once

#include <functional>

#include "component.hh"

extern "C" {
#include "esp_log.h"
#include "lvgl_port.h"
}

#ifndef APPLICATION_H
#define APPLICATION_H
#endif //APPLICATION_H

#include <ctime>
#include <string>

namespace base_widgets {

    class Application {
    private:
        lv_obj_t* screen = nullptr;

    public:
        Application(lv_obj_t* screen_v);
        virtual ~Application() = default;
        void renderApp(Component* base) const;
        void tick(lv_obj_t* scr, std::function<void()> callback);
        void turnOnBacklight();
        void turnOffBacklight();
    };

    inline Application::Application(lv_obj_t* screen_v) {
        this->screen = screen_v;
    };


    inline void Application::turnOnBacklight() {
        // waveshare_rgb_lcd_bl_on();
    }

    inline void Application::turnOffBacklight() {
        // waveshare_rgb_lcd_bl_off();
    }

    inline void Application::renderApp(Component* base) const {
        if (base == nullptr || this->screen == nullptr) return;
        lv_obj_clean(this->screen);
        base->render();
    }


    inline void Application::tick(lv_obj_t* scr, std::function<void()> callback) {
        if (lvgl_port_lock(-1)) {
#ifndef IS_MULTITHREAD
            ESP_LOGI("App", "Running on single-threaded LVGL loop");
#endif

            std::time_t result = std::time(nullptr);
            std::string timeStr = std::asctime(std::localtime(&result));
            ESP_LOGI("App", "Start time: %s", timeStr.c_str());
            callback();
            lvgl_port_unlock();
        }

    }

} // namespace base_widgets
