//
// Created by evgeniy on 3/18/25.
//

//file used for make ide look up into hh files

#include "application.hh"
#include "component.hh"

extern "C" {
#include "../lvgl__lvgl/demos/lv_demos.h"
#include "../../main/core/lvgl_port.h"
}
