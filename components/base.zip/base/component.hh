//
// Created by evgeniy on 3/29/25.
//
#pragma once

#include <memory>

#include "base_widget.hh"


extern "C" {
#include "lv_demos.h"
#include "lvgl_port.h"
}

namespace base_widgets {
    class Component {
    private:
        std::shared_ptr<Styling> style;
        lv_obj_t* component;

    public:
        virtual ~Component() = default;

        explicit Component(lv_obj_t *obj) : style(nullptr), component(obj) {}

        virtual lv_obj_t* render() = 0;
        virtual Styling styling() = 0;
        virtual Component* append(lv_obj_t *obj) = 0;

        lv_obj_t *get_component() const { return this->component; }
        lv_obj_t *set_component(lv_obj_t* v) { this->component = v;  return this->component; }

        void set_active(bool active) const {
            if (this->component != nullptr)
                lv_obj_add_flag(this->component, active ? LV_OBJ_FLAG_CLICKABLE : LV_OBJ_FLAG_HIDDEN);
        }

        void set_style(const std::shared_ptr<Styling> &newStyle) {
            this->style = newStyle;

            if (this->component && this->style) {
                lv_obj_add_style(this->component, this->style->getStyle(), 0);
            }
        }
    };
}
