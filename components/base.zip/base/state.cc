#ifndef STATE_HH
#define STATE_HH

#include <functional>
#include <map>
#include <string>

namespace base_widgets {
    template<typename T>
    class State {
    private:
        T value;
        std::map<std::string, std::function<void(const T&)>> listeners;

    public:
        explicit State(const T& initial) : value(initial) {}

        const T& get() const {
            return value;
        }

        void set(const T& newValue) {
            if (newValue != value) {
                value = newValue;
                for (const auto& [_, callback] : listeners) {
                    callback(value);
                }
            }
        }

        void subscribe(const std::string& label, const std::function<void(const T&)>& listener) {
            listeners[label] = listener;
        }

        void unsubscribe(const std::string& label) {
            listeners.erase(label);
        }

        void destroy() {
            listeners.clear();
        }
    };

} // namespace base_widgets

#endif // STATE_HH
